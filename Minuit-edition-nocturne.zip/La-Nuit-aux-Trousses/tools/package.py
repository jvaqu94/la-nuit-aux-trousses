"""Reconstruit l’édition autonome et l’archive sans données privées."""
from pathlib import Path
import re, zipfile, base64, json

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text()

for name in ['supabase-config.js', 'characters.js', 'music.js', 'game.js', 'online.js', 'journey.js', 'viewport.js', 'arsenal-art.js', 'arsenal.js', 'collectible-art.js', 'night-hazards.js', 'adventure.js', 'encounters.js', 'flow.js', 'surprise.js', 'coven.js', 'nemesis.js', 'combat-feel.js', 'onboarding.js', 'collision-replay.js', 'supabase.js', 'settings-page.js', 'home.js', 'arcade-scores.js', 'synergies.js', 'weekly.js', 'level-rewards.js', 'replay.js', 'sequel.js', 'sequel-bestiary.js', 'sequel-art.js', 'sixth-hour.js', 'sixth-hour-art.js', 'sixth-scenery.js', 'sixth-labyrinth.js', 'daily-rewards.js', 'duel-core.js', 'qrcode.js', 'duel-qr.js', 'night-duel.js']:
    code = (ROOT / name).read_text().replace('</script', '<\\/script')
    if name == 'weekly.js':
        scenes = {name: 'data:image/jpeg;base64,' + base64.b64encode((ROOT / 'scenery' / f'{name}.jpg').read_bytes()).decode('ascii') for name in ['forest', 'cemetery', 'castle']}
        scenes['stone'] = 'data:image/jpeg;base64,' + base64.b64encode((ROOT / 'scenery' / 'runner-stone-texture.jpg').read_bytes()).decode('ascii')
        scenes['wood'] = 'data:image/jpeg;base64,' + base64.b64encode((ROOT / 'scenery' / 'runner-wood-texture.jpg').read_bytes()).decode('ascii')
        code = 'window.MinuitRunnerSceneryData=' + json.dumps(scenes, separators=(',', ':')) + ';\n' + code
    if name == 'music.js':
        sources = {}
        for track in ['menu', 'menu-sequel', 'forest', 'cemetery', 'castle', 'marsh', 'lanterns', 'sequel-city', 'sequel-desert', 'sequel-clockforest', 'sequel-train', 'sequel-palace', 'world3-faubourg', 'world3-clocher', 'world3-estran', 'world3-lanternes-rendues', 'world3-cadran-noir']:
            filename = {'menu':'nuitsorc-loop','menu-sequel':'sequel-menu'}.get(track,track)
            sources[track] = 'data:audio/mpeg;base64,' + base64.b64encode((ROOT / 'audio' / f'{filename}.mp3').read_bytes()).decode('ascii')
        sources.update({'boss-' + track: 'data:audio/mpeg;base64,' + base64.b64encode((ROOT / 'audio' / f'boss-{track}.mp3').read_bytes()).decode('ascii') for track in ['forest', 'cemetery', 'castle', 'marsh', 'lanterns']})
        sources['defeat'] = 'data:audio/mpeg;base64,' + base64.b64encode((ROOT / 'audio' / 'defeat.mp3').read_bytes()).decode('ascii')
        code = 'window.MinuitMusicData=' + json.dumps(sources, separators=(',', ':')) + ';\n' + code
    if name == 'game.js':
        sfx = {
            key: 'data:audio/mpeg;base64,' + base64.b64encode((ROOT / path).read_bytes()).decode('ascii')
            for key, path in {
                'shot': 'audio/sfx-player-shot.mp3',
                'spread': 'audio/sfx-player-spread.mp3',
                'missile': 'audio/sfx-player-missile.mp3',
                'laser': 'audio/sfx-player-laser.mp3',
                'special': 'audio/sfx-player-special.mp3',
                'impactLight': 'audio/sfx-impact-light.mp3',
                'impactHeavy': 'audio/sfx-impact-heavy.mp3',
                'impactBoss': 'audio/sfx-impact-boss.mp3',
                'lifeLoss': 'audio/sfx-player-life-loss.mp3',
                'obstacleCollision': 'audio/sfx-obstacle-collision.mp3',
                'surpriseMonster': 'audio/sfx-surprise-monster.mp3',
                'pickup': 'audio/sfx-pickup-bonus.mp3',
                'bossDive': 'audio/sfx-boss-dive.mp3',
                'obstacleHit': 'audio/sfx-obstacle-hit.mp3',
                'obstacleBreak': 'audio/sfx-obstacle-break.mp3',
                'chestTouch': 'audio/sfx-chest-touch.mp3',
                'chestOpen': 'audio/sfx-chest-open.mp3',
                'lifeLossClear': 'audio/sfx-life-loss-clear.mp3',
                'killGhost': 'audio/sfx-kill-ghost.mp3',
                'killSkull': 'audio/sfx-kill-skull.mp3',
                'killVampire': 'audio/sfx-kill-vampire.mp3',
                'killSpider': 'audio/sfx-kill-spider.mp3',
                'killDemon': 'audio/sfx-kill-demon.mp3',
            }.items()
        }
        code = 'window.MinuitSfxData=' + json.dumps(sfx, separators=(',', ':')) + ';\n' + code
    html = re.sub(r'<script src="' + re.escape(name) + r'(?:\?[^"]*)?"></script>', lambda m: '<script>' + code + '</script>', html)

(ROOT / 'La-Nuit-aux-Trousses.html').write_text(html)
# Alias historiques maintenus pour les anciens liens et outils.
(ROOT / 'minuit-autonome.html').write_text(html)

with zipfile.ZipFile(ROOT / 'La-Nuit-aux-Trousses.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in ['index.html', 'supabase-config.js', 'characters.js', 'music.js', 'game.js', 'online.js', 'journey.js', 'viewport.js', 'arsenal-art.js', 'arsenal.js', 'collectible-art.js', 'night-hazards.js', 'adventure.js', 'encounters.js', 'flow.js', 'surprise.js', 'coven.js', 'nemesis.js', 'combat-feel.js', 'onboarding.js', 'collision-replay.js', 'supabase.js', 'settings-page.js', 'home.js', 'arcade-scores.js', 'synergies.js', 'weekly.js', 'level-rewards.js', 'replay.js', 'sequel.js', 'sequel-bestiary.js', 'sequel-art.js', 'sixth-hour.js', 'sixth-hour-art.js', 'sixth-scenery.js', 'sixth-labyrinth.js', 'daily-rewards.js', 'duel-core.js', 'qrcode.js', 'duel-qr.js', 'night-duel.js', 'server.py', 'README.md', 'audio/README.md', 'supabase/README.md', 'supabase/schema.sql', 'supabase/teams.sql', 'supabase/team_rules.sql', 'supabase/team_stats.sql', 'supabase/team_periods.sql', 'supabase/team_legacy_highscores.sql', 'supabase/weekly_sprint.sql', 'supabase/ring_sprint.sql', 'supabase/broom_sprint.sql', 'supabase/candy_sprint.sql', 'supabase/candy_sprint_v2.sql', 'supabase/candy_sprint_v3.sql', 'supabase/candy_sprint_v4.sql', 'supabase/candy_sprint_v5.sql', 'supabase/night_duels.sql', 'supabase/functions/email-confirmation/index.ts', 'supabase/functions/pseudo-auth/index.ts', 'La-Nuit-aux-Trousses.html', 'tools/package.py', 'tools/generate_music.py']:
        z.write(ROOT / name, 'La-Nuit-aux-Trousses/' + name)
    for path in sorted((ROOT / 'audio').glob('*.mp3')):
        z.write(path, 'La-Nuit-aux-Trousses/' + str(path.relative_to(ROOT)))
    for path in sorted((ROOT / 'scenery').glob('*.jpg')):
        z.write(path, 'La-Nuit-aux-Trousses/' + str(path.relative_to(ROOT)))
    for name in ['test_settings_audio.py', 'test_soundtrack.py', 'test_music_mp3.py', 'test_supabase.py', 'test_teams.py', 'test_team_stats_activity.py', 'test_team_activity_sql.cjs', 'test_team_periods_sql.cjs', 'test_cloud_sync.cjs', 'cloud-sync-harness.cjs', 'test_training_profile.cjs', 'test_team_periods.py', 'test_pseudo_invite.py', 'test_rival_replay.py', 'test_coven_dawn.py', 'test_sequel.py', 'test_sequel_bestiary.py', 'test_sequel_art.py', 'test_daily_rewards.py', 'test_vertical_drift.py', 'test_surprise_ui.py', 'test_flow.py', 'test_enemy_walls.py', 'test_sealed_chest.py', 'test_bonus_art.py', 'test_collectibles_art.py', 'test_encounters.py', 'test_combat_feel.py', 'test_dodge_near_miss.py', 'test_life_flash.py', 'test_audio_feedback.py', 'test_audio_assets.py', 'test_onboarding.py', 'test_adventure.py', 'test_charges_sweets.py', 'test_arsenal_browser.py', 'test_touch_controls.py', 'test_viewport.py', 'test_journey_browser.py', 'test_journey_campaign.py', 'test_no_account_browser.py', 'test_home.py', 'test_mode_selection_browser.py', 'test_ranked_team_gate.py', 'test_replayability.py', 'test_ring_sprint.py', 'test_weekly_sprint_sql.py', 'test_settings_page.py', 'test_arcade_scores.py', 'test_highscore.cjs', 'test_loot.cjs', 'test_flight.cjs', 'test_arcade.cjs', 'test_level_rewards.cjs', 'test_boss_zones.cjs', 'test_level_rewards_browser.py', 'test_night_duel_core.cjs', 'test_night_duel_browser.cjs', 'test_journey_run_accessor.cjs', 'test_night_duel_entry.cjs', 'test_duel_qr.cjs', 'qr-harness.cjs', 'test_duel_invitations_sql.cjs', 'night_duels_transaction.sql']:
        z.write(ROOT / 'tests' / name, 'La-Nuit-aux-Trousses/tests/' + name)

import shutil
shutil.copyfile(ROOT / 'La-Nuit-aux-Trousses.zip', ROOT / 'Minuit-edition-nocturne.zip')
print('La Nuit aux Trousses : archive et HTML autonome prêts : Grimoire intégré, aucune base ni sauvegarde personnelle incluse.')
