# La Nuit aux Trousses

**La Nuit aux Trousses** est un shoot’em up vertical sur le thème d’Halloween. Aux commandes de son balai, une sorcière doit traverser cinq univers, survivre à 25 vagues et vaincre cinq gardiens avant l’aube.

Le jeu fonctionne dans le navigateur, y compris hors ligne, sans compte ni installation. Il utilise uniquement HTML, CSS et JavaScript natifs : Canvas 2D, illustrations SVG, Web Audio et stockage local. Aucune bibliothèque, police, image ou musique distante n’est nécessaire pendant le jeu.

## Sommaire

- [Démarrage rapide](#démarrage-rapide)
- [Commandes](#commandes)
- [Modes de jeu](#modes-de-jeu)
- [Contenu et mécaniques](#contenu-et-mécaniques)
- [Progression et sauvegardes](#progression-et-sauvegardes)
- [Supabase : cloud, teams et avis](#supabase--cloud-teams-et-avis)
- [Affichage et son](#affichage-et-son)
- [Structure du projet](#structure-du-projet)
- [Tests](#tests)
- [Générer les versions distribuables](#générer-les-versions-distribuables)
- [Notes techniques](#notes-techniques)

## Démarrage rapide

### Jouer hors ligne

Ouvrir **`La-Nuit-aux-Trousses.html`** dans un navigateur récent.

Cette version autonome regroupe tout le code et toutes les ressources dans un seul fichier. Elle ne demande ni Python, ni serveur, ni connexion réseau.

> Le stockage des pages ouvertes avec `file://` dépend du navigateur. Pour une sauvegarde locale plus fiable, utiliser le serveur local ci-dessous et exporter régulièrement sa progression.

### Lancer un serveur local

**Prérequis :** Python 3.9 ou supérieur, avec les données de fuseaux horaires du système.

À la racine du projet :

```bash
python server.py
```

Puis ouvrir <http://localhost:3000>.

Le serveur écoute sur toutes les interfaces. Pour utiliser un autre port :

```bash
PORT=8080 python server.py
```

Aucune dépendance Python externe n’est nécessaire pour lancer le jeu. L’interface actuelle fonctionne sans compte et n’appelle pas les anciennes API de ligue.

## Commandes

Le tir principal est **automatique**.

| Action | Clavier | Souris / tactile | Manette compatible Gamepad API |
|---|---|---|---|
| Se déplacer | Flèches, ZQSD ou WASD | Pointer à la souris ; glisser sur le terrain au doigt | Stick gauche |
| Mouvement de précision | Maj | — | Gâchette |
| Esquive | Espace | Bouton **Esquive** | A / bouton 0 |
| Sort spécial | F | Bouton **Sort spécial** | X / bouton 2 |
| Pause | P ou Échap | Bouton **Pause** | Start |

- La précision ralentit le déplacement et affiche la zone de collision de la sorcière.
- L’esquive et le sort spécial possèdent chacun un temps de recharge. Avec le balai initial, l’esquive protège pendant **0,45 s** et se recharge en **4 s** : il faut l’utiliser au contact du danger, pas trop tôt.
- Lors du premier apprentissage, un projectile réel est entouré et le bouton s’illumine au bon moment. Une esquive qui traverse effectivement un tir produit un retour distinct et valide ce guide ; **Revoir les conseils** permet de le réactiver.
- Sur tactile, le glisser est relatif : poser le doigt ne téléporte pas la sorcière. Une pastille indique le point de départ et le mouvement. Un second doigt peut déclencher **Sort spécial** ou **Esquive** sans interrompre le pilotage.
- Les touches principales peuvent être reconfigurées dans **Réglages**.
- Le son est désactivé par défaut et s’active avec le bouton **Son**.

## Modes de jeu

| Mode | Règles principales |
|---|---|
| **Aventure libre** | Vols illimités, difficulté réglable, progression et records personnels. |
| **Défi score** | Trois essais par jour, en difficulté **Nuit noire**. Seule l’amélioration du meilleur score du jour augmente le cumul local. |
| **Défi primes** | Un essai séparé par jour et trois objectifs à prime unique. Le score brut de cet essai ne constitue pas un quatrième score classé. |
| **Laboratoire** | Entraînement libre avec les sorts, balais, compagnons, variantes et charges de boss. Ne crédite ni score, ni XP, ni déblocage et ne consomme aucun essai quotidien. |

Les essais et objectifs quotidiens sont renouvelés à minuit, heure d’**Europe/Paris**. Leur comptage est local : il ne s’agit ni d’un système compétitif sécurisé ni d’un mécanisme anti-triche.

Les défis imposent l’équipement de base afin que l’Arsenal débloqué dans l’aventure ne donne pas d’avantage permanent.

## Contenu et mécaniques

### Campagne

| Univers | Gardien |
|---|---|
| La forêt des murmures | Jack, le roi creux |
| Le cimetière oublié | Le fossoyeur éternel |
| Le château des vampires | La comtesse de minuit |
| Le marais des sorcières | La tisseuse des marais |
| La fête des ombres | Le dévoreur de lanternes |

Chaque univers comprend cinq vagues, puis un gardien en trois phases. La difficulté **Clair de lune**, **Nuit noire** ou **Cauchemar** peut être choisie pour l’aventure libre.

La campagne comprend notamment :

- des formations de créatures, des élites et des petits groupes coopératifs ; les champions de rang 2 sont présentés comme des mini-boss avec nom, barre de vie et indice sur leurs attaques ;
- des barrières, des passages, des rochers et des obstacles destructibles ;
- des charges de boss propres à chaque gardien ;
- des séquences de terrain propres aux cinq univers ;
- **le Veilleur**, un chasseur récurrent qui intervient pendant les quatrièmes vagues ;
- une scène de victoire à l’aube après le dernier gardien.

Les transitions utilisent des fondus sans interrompre le combat : les ennemis, projectiles et objets déjà présents ne sont pas supprimés arbitrairement.

### Arsenal et reliques

Le menu **Préparer mon vol** permet de choisir :

- un **sort actif**, déclenché manuellement ;
- un **balai**, qui modifie le pilotage ou l’esquive ;
- un **compagnon de combat**, avec ses avantages et ses contreparties.

Ces éléments et leurs variantes se débloquent par objectifs cumulatifs. Les choix sont conservés et figés pour le vol en cours.

Pendant une partie, les reliques ramassées renforcent temporairement l’armement : cadence, projectiles, poison, missiles, familiers, tirs traversants ou rayon. Leur effet est résumé sous leur nom et expliqué au ramassage. Elles ne remplacent pas le sort actif. La plupart de ces améliorations se déchargent au changement d’univers.

### Confort de combat

Sur téléphone, les textes essentiels sont agrandis sans réduire le terrain ni les cibles tactiles. Les projectiles ennemis possèdent des couleurs distinctes, un contour sombre et un repère lumineux ; ces ajouts graphiques ne changent pas leur hitbox. Les impacts renforcent le flash et l’impulsion déjà présents, avec au plus un son de dégât toutes les 65 ms pour éviter la saturation. Il n’y a ni secousse d’écran ni option de facilité.

Les bonbons apportent de l’XP, des points ou un bouclier. Des cœurs peuvent restaurer une vie. Les coffres scellés doivent être dégagés de leurs rochers puis ouverts avant de récupérer leur butin.

### Score et Grimoire

Le **score** et l’**XP** sont deux progressions distinctes :

- le score dépend notamment des éliminations, des combos, des frôlements et des objectifs de défi ;
- l’XP alimente les niveaux et la **Collection** du Grimoire ;
- les apparences de la Collection sont cosmétiques ;
- les capacités réelles de l’Arsenal se débloquent séparément, par exploits.

Le Grimoire contient également les contrats quotidiens, les exploits, les records, le bilan des vols et le journal local.

### Reconstitution du coup fatal

Après une défaite, **Revoir le coup fatal** permet de rejouer une reconstitution des cinq dernières secondes disponibles avant le choc, avec pause, ralenti et curseur temporel.

Cette fonction n’enregistre ni vidéo ni son. Elle ne modifie ni la partie terminée, ni les scores, ni les sauvegardes.

## Progression et sauvegardes

Par défaut, la progression est enregistrée dans le **`localStorage` du navigateur**, sans compte. Une synchronisation Supabase optionnelle peut être activée dans **Sauvegarde** pour la retrouver sur un autre appareil.

- Un point de reprise est enregistré au début des vagues.
- Les records sont séparés par difficulté et par date pour les défis.
- La reprise d’un défi existant ne consomme pas un nouvel essai.
- Le Laboratoire préserve la progression et le point de reprise du vol en cours.
- Effacer les données du site ou du navigateur peut effacer définitivement la progression locale.

Le menu **Sauvegarde**, également accessible depuis les réglages, permet d’exporter un fichier JSON contenant notamment la progression, les records, les réglages et le point de reprise.

> **Avant de changer de navigateur ou d’appareil sans cloud, exporter sa sauvegarde.** L’import remplace les données actuelles au lieu de les fusionner. Les fichiers sont validés avant écriture, limités à 2 Mo et le dernier import peut être annulé.

## Supabase : cloud, teams et avis

La configuration publique du projet est déjà renseignée dans `supabase-config.js` et le schéma `supabase/schema.sql` est appliqué avec ses règles RLS. Le menu **Sauvegarde & team** permet de créer un compte e-mail, d’envoyer sa progression et de la récupérer sur un autre appareil. Après un premier envoi manuel, les modifications sont synchronisées automatiquement au maximum toutes les 30 secondes.

La sauvegarde cloud est **optionnelle** : le jeu local et les exports restent disponibles sans compte ou hors ligne. Un compte possède un emplacement, remplacé à chaque envoi. Le mot de passe n’est pas stocké par le jeu et la session Supabase n’est jamais incluse dans les exports.

La confirmation d’adresse reste obligatoire. Les nouveaux liens aboutissent à la page Supabase **`email-confirmation`**, indépendante de la prévisualisation Arena : après confirmation, revenir dans le jeu et se connecter. Si un ancien e-mail affiche **Missing traffic access token**, saisir son adresse dans **Sauvegarde & team**, puis choisir **Renvoyer la confirmation** et ouvrir uniquement le nouveau lien.

### Teams et highscores

Le menu **Sauvegarde & team** permet, après connexion, de créer une team ou de rejoindre celle d’un autre joueur avec un code de 10 caractères. Chaque joueur choisit un pseudo : les adresses e-mail ne sont jamais affichées dans le classement.

- Un compte appartient à une seule team à la fois ; il doit la quitter avant d’en rejoindre une autre.
- **Le créateur devient administrateur** et configure les règles dès la création : 1 à 100 parties comptabilisées par joueur et par jour, ou illimité, ainsi qu’une période optionnelle de début et de fin.
- Seul l’administrateur peut modifier ces règles ou supprimer explicitement la team. S’il quitte la team sans la supprimer, le membre le plus ancien reprend ce rôle.
- Sur smartphone, le code peut être partagé par **WhatsApp** ou **Messenger**. Le lien `?team=CODE` préremplit le code dans **Sauvegarde & team**, sans inclure de jeton de session.
- Après chaque vol, le score est transmis automatiquement. Chaque vol comptabilisé consomme une partie du jour, même s’il n’améliore pas le record ; un identifiant unique évite le double comptage en cas de renvoi.
- La limite quotidienne suit le fuseau **Europe/Paris**. Hors période ou au-delà de la limite, le vol reste jouable localement mais ne compte pas pour la team.
- Seul le **meilleur score de chaque membre** est conservé ; le tableau affiche aussi le total de ces records et les parties restantes.
- Quitter la team retire le score et les tentatives du joueur de son classement. Une team vide est supprimée.
- Les tables de teams ne sont pas accessibles directement par l’API : des fonctions authentifiées contrôlent chaque opération et aucune donnée de team n’est publique.

Les fichiers `supabase/teams.sql` et `supabase/team_rules.sql` contiennent le schéma et ces fonctions. Le classement est **amical** : le serveur vérifie le compte, la team et les valeurs transmises, mais ne peut pas prouver le déroulé d’une partie exécutée dans un navigateur modifiable. Une compétition anti-triche nécessiterait une validation serveur ou un système de rejeu signé.

Le bilan de vol conserve toujours localement l’appréciation **Trop difficile / Bien dosé / Trop facile** et un commentaire facultatif. Avec Supabase configuré, une copie privée peut être envoyée pour l’équilibrage, même sans compte. Les avis ne sont pas publiés dans le jeu et aucune lecture publique de leur table n’est autorisée.

La procédure complète et les consignes de sécurité sont dans [`supabase/README.md`](supabase/README.md). **Aucune clé secrète ou `service_role` ne doit être placée dans le navigateur.**

## Affichage et son

- Terrain au format 8:9 sur ordinateur et en paysage. En portrait sur mobile, il peut occuper davantage de hauteur, jusqu’à un rapport hauteur/largeur de 1,45, selon la place disponible.
- Interface dédiée sur mobile, commandes principales agrandies et panneau d’informations séparé avec mise en pause.
- Mode plein écran lorsque le navigateur l’autorise.
- Volume, musique et ambiance réglables sans modifier la partie.
- Six boucles **MP3 locales, stéréo, 44,1 kHz** : le thème fourni **`nuitsorc-loop.mp3`** dans le menu, utilisé sans réencodage, et cinq adaptations d’univers encodées en 192 kbit/s. Elles sont décodées par Web Audio, avec fondu entre les mondes et bouclage précis.
- Cinq adaptations distinctes : **Murmures de bruyère** (forêt), **Cloches de l’oubli** (cimetière), **Valse carmin** (château), **Rondes des limons** (marais) et **Farandole des ombres** (lanternes).
- Chaque univers reprend des phrases différentes du thème fourni, avec son montage, son tempo, sa largeur stéréo et son ambiance. Pendant les gardiens, le thème MP3 accélère de 8 % avec une transition progressive.
- Cinq motifs MP3 signalent les créatures ordinaires ; **`boss-arrival.mp3`** est réservé aux gardiens. Ces signaux passent par le bus des effets et restent indépendants du réglage de musique. L’arrivée du boss s’accompagne d’une courte atténuation de sa boucle.
- Les autres effets, le vent et le bruit rose restent générés localement. Si une boucle est absente ou illisible, l’ancienne partition procédurale du monde prend le relais sans interrompre les effets sonores.
- Aucun service musical externe n’est utilisé. Le HTML autonome embarque les douze MP3 et fonctionne hors ligne ; seuls deux tampons de musique décodés sont conservés à la fois pour limiter la mémoire. Les crédits et l’attribution FluidR3_GM / CC BY 3.0 des arrivées ordinaires figurent dans [`audio/README.md`](audio/README.md).
- Pause automatique lorsque la fenêtre perd le focus, identique pour toutes les parties.

Hors choix explicite du niveau de difficulté, les réglages ne modifient pas le challenge. Les secousses ont été supprimées et aucune option ne permet de désactiver les apparitions ou d’alléger les effets et la présentation des dangers. Les anciennes préférences de ce type sont ignorées lors du chargement et retirées lors de la prochaine sauvegarde. Le jeu contient des effets lumineux et ne propose plus de mode visuel allégé.

## Structure du projet

| Fichier ou dossier | Rôle |
|---|---|
| `index.html` | Page d’entrée et chargement des modules JavaScript. |
| `game.js` | Boucle de jeu, campagne, ennemis, boss, collisions, score et interface principale. |
| `music.js` | Lecteur local des boucles MP3, fondus, bouclage, intensification et mémoire limitée. |
| `audio/` | Thème d’accueil, cinq adaptations, six signaux d’arrivée et crédits audio. |
| `characters.js` | Illustrations SVG des personnages et ressources visuelles intégrées. |
| `journey.js` | Grimoire, XP, contrats, collection, bilans, avis et export/import. |
| `online.js` | Défis et cumul locaux, sans compte dans l’interface actuelle. |
| `arsenal.js` | Sorts, balais, compagnons et équipement. |
| `adventure.js` | Exploits, variantes, Laboratoire et coffres scellés. |
| `encounters.js` | Formations, séquences de terrain, statistiques de vol et confort. |
| `night-hazards.js` | Obstacles, charges des gardiens et bonbons. |
| `flow.js` | Fondus et continuité des transitions. |
| `surprise.js` | Apparitions soudaines et présentation de la défaite. |
| `coven.js` | Coopération entre créatures et scène de victoire. |
| `nemesis.js` | Rencontres avec le Veilleur. |
| `collision-replay.js` | Reconstitution locale du coup fatal. |
| `collectible-art.js` | Illustrations des bonus et objets ramassables. |
| `viewport.js` | Adaptation du terrain, des commandes tactiles et de l’affichage à la fenêtre. |
| `supabase.js` | Client REST Supabase optionnel, authentification, cloud, teams, highscores et avis. |
| `supabase-config.js` | URL et clé publiable du projet ; des valeurs vides désactivent le cloud pour un fonctionnement local. |
| `supabase/` | Schéma SQL RLS et guide de configuration. |
| `server.py` | Serveur HTTP local et ancien backend SQLite de ligue. |
| `scenery/` | Images sources des décors. |
| `tests/` | Tests Node, Python et Playwright, ainsi que leurs captures. |
| `tools/generate_music.py` | Montage stéréo des cinq adaptations à partir du thème fourni, avec NumPy, SciPy, SoundFile et lameenc. |
| `tools/package.py` | Génération du HTML autonome et des archives, avec les MP3 incorporés. |
| `La-Nuit-aux-Trousses.html` | Version autonome générée, prête à jouer. |
| `La-Nuit-aux-Trousses.zip` | Archive distribuable générée. |

Les fichiers `minuit-autonome.html`, `Minuit-edition-nocturne.zip` et `minuit-v1.html` sont conservés pour compatibilité ou historique. Les scripts `patch_*.py`, le fragment `bonus_art_fragment.txt` et `online-accounts-backup.js` ne sont pas nécessaires pour jouer.

Modifier les fichiers sources plutôt que le HTML autonome, qui est régénéré par l’outil de packaging.

## Tests

### Prérequis

Les tests `.cjs` demandent **Node.js**. Les tests navigateur demandent **Python**, **Playwright** et **Chromium** :

```bash
python -m pip install playwright
python -m playwright install chromium
```

La plupart des tests Playwright attendent le jeu sur le port 3000. Dans un premier terminal :

```bash
python server.py
```

Les tests Playwright utilisent des navigateurs isolés et ne partagent pas la progression du joueur.

### Tests Node

À exécuter depuis la racine du projet :

```bash
node tests/test_highscore.cjs
node tests/test_loot.cjs
node tests/test_flight.cjs
node tests/test_arcade.cjs
node tests/balance-node.cjs
```

### Tests navigateur principaux

```bash
python tests/test_settings_audio.py
python tests/test_soundtrack.py
python tests/test_music_mp3.py
python tests/test_supabase.py
python tests/test_teams.py
python tests/test_journey_browser.py
python tests/test_no_account_browser.py
python tests/test_arsenal_browser.py
python tests/test_adventure.py
python tests/test_encounters.py
python tests/test_combat_feel.py
python tests/test_flow.py
python tests/test_surprise_ui.py
python tests/test_vertical_drift.py
python tests/test_coven_dawn.py
python tests/test_rival_replay.py
python tests/test_sealed_chest.py
python tests/test_bonus_art.py
python tests/test_collectibles_art.py
python tests/test_charges_sweets.py
python tests/test_touch_controls.py
python tests/test_viewport.py
```

La campagne technique complète se vérifie avec :

```bash
python tests/test_journey_campaign.py
```

Cette campagne automatique utilise l’invulnérabilité pour contrôler les 25 vagues, les cinq gardiens et les événements. Elle valide l’intégration technique, **pas l’équilibrage ressenti par un joueur**.

Les tests `tests/test_league_server.py` et `tests/test_league_browser.py` concernent l’ancienne ligue avec comptes et utilisent des données temporaires. Ils sont distincts du parcours local actuel.

## Générer les versions distribuables

Les MP3 sont déjà fournis et aucune bibliothèque n’est nécessaire pour les écouter. Pour reconstruire les cinq adaptations de monde à l’identique, l’outil facultatif utilise Python, NumPy, SciPy, SoundFile et lameenc. Le thème du menu, l’arrivée du boss et les arrivées ordinaires ne sont pas réencodés :

```bash
python -m pip install numpy scipy soundfile lameenc
python tools/generate_music.py
```

Après une modification des sources, des MP3 ou de ce README :

```bash
python tools/package.py
```

Le script régénère :

- `La-Nuit-aux-Trousses.html` ;
- son alias historique `minuit-autonome.html` ;
- `La-Nuit-aux-Trousses.zip` ;
- son alias historique `Minuit-edition-nocturne.zip`.

Les archives sont construites à partir d’une liste explicite de fichiers. Les bases SQLite, sauvegardes personnelles et captures de test n’y sont pas incluses.

## Notes techniques

- **Aucun build ni framework** n’est nécessaire pour jouer ou développer.
- Le jeu n’a pas de dépendance JavaScript ou Python externe à l’exécution. NumPy, SciPy, SoundFile et lameenc ne servent qu’à régénérer les adaptations, déjà fournies en MP3.
- Les scripts, images et douze MP3 de la version autonome sont intégrés au fichier HTML, ces derniers en data URI.
- Le parcours local ne demande aucun compte. La sauvegarde cloud et les teams sont optionnelles ; il n’existe aucun classement mondial public.
- Le serveur conserve d’anciennes routes de ligue et une base SQLite pour des raisons historiques ; elles ne sont pas utilisées par le parcours local actuel.
- Le stockage local est modifiable par l’utilisateur et ne fournit aucune protection anti-triche.
- La compatibilité manette dépend du navigateur et du mapping du matériel.

Le projet s’appelait auparavant **Minuit — La chasse maudite**. Les clés `minuit-*`, le format `MinuitProgression` et plusieurs noms de fichiers sont volontairement conservés afin de préserver les sauvegardes et les exports existants.
