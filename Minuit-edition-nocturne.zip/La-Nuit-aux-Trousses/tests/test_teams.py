import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from urllib.parse import parse_qs, unquote, urlsplit

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://night-test.supabase.co'
ALICE = '4b1b47de-40f2-45f4-a62c-0f702d85ba01'
BOB = '84f2f696-f9f4-4e6f-a25f-62746c598315'
CODE = 'ABCDE23456'
users = {'alice@example.com': ALICE, 'bob@example.com': BOB}
team = None
stats_error_once = False
calls = []
PARIS = ZoneInfo('Europe/Paris')


def games_remaining(member):
    limit = team['dailyGameLimit']
    return None if limit is None else max(0, limit - len(member['attempts']))


def member_state(user_id):
    if not team or user_id not in team['members']:
        return {'team': None, 'scores': []}
    members = team['members']
    member = members[user_id]
    ordered = sorted(
        members.items(),
        key=lambda item: (-(item[1].get('score') or 0), item[1]['displayName'].lower()),
    )
    scores = []
    for rank, (member_id, row) in enumerate(ordered, 1):
        scores.append({
            'rank': rank,
            'displayName': row['displayName'],
            'score': row.get('score') or 0,
            'mode': row.get('mode'),
            'difficulty': row.get('difficulty'),
            'stage': row.get('stage'),
            'wave': row.get('wave'),
            'updatedAt': row.get('updatedAt'),
            'isYou': member_id == user_id,
            'isAdmin': member_id == team['adminId'],
        })
    return {
        'team': {
            'id': team['id'],
            'name': team['name'],
            'code': team['code'],
            'memberCount': len(members),
            'totalScore': sum(row.get('score') or 0 for row in members.values()),
            'isAdmin': team['adminId'] == user_id,
            'rulesConfigured': team['rulesConfigured'],
            'dailyGameLimit': team['dailyGameLimit'],
            'startsAt': team['startsAt'],
            'endsAt': team['endsAt'],
            'gamesToday': len(member['attempts']),
            'gamesRemaining': games_remaining(member),
        },
        'scores': scores,
    }


def team_stats_state(user_id, days):
    until = datetime.now(PARIS).date()
    since = until - timedelta(days=days - 1)
    rows = []
    for member_id, member in team['members'].items():
        for attempt in member['attempts']:
            played_on = datetime.fromisoformat(attempt['playedOn']).date()
            if since <= played_on <= until:
                rows.append({
                    **attempt,
                    'userId': member_id,
                    'displayName': member['displayName'],
                })

    def progress(attempts):
        return max((row['stage'] * 10 + row['wave'] for row in attempts), default=0)

    daily = []
    for played_on in sorted({row['playedOn'] for row in rows}, reverse=True):
        attempts = [row for row in rows if row['playedOn'] == played_on]
        daily.append({
            'playedOn': played_on,
            'games': len(attempts),
            'points': sum(row['score'] for row in attempts),
            'bestScore': max(row['score'] for row in attempts),
            'bestProgress': progress(attempts),
        })

    members = []
    for member_id, member in team['members'].items():
        attempts = [row for row in rows if row['userId'] == member_id]
        members.append({
            'displayName': member['displayName'],
            'games': len(attempts),
            'points': sum(row['score'] for row in attempts),
            'bestScore': max((row['score'] for row in attempts), default=0),
            'bestProgress': progress(attempts),
            'lastPlayedAt': max((row['playedAt'] for row in attempts), default=None),
            'isAdmin': member_id == team['adminId'],
            'isYou': member_id == user_id,
        })
    members.sort(key=lambda row: (-row['points'], row['displayName'].lower()))

    recent = []
    for row in sorted(rows, key=lambda item: (item['playedAt'], item['runId']), reverse=True)[:50]:
        recent.append({
            key: row[key]
            for key in ['playedAt', 'playedOn', 'displayName', 'score', 'stage', 'wave', 'mode', 'difficulty']
        } | {'isYou': row['userId'] == user_id})

    return {
        'team': {'name': team['name']},
        'period': {'days': days, 'since': since.isoformat(), 'until': until.isoformat()},
        'summary': {
            'games': len(rows),
            'points': sum(row['score'] for row in rows),
            'bestScore': max((row['score'] for row in rows), default=0),
            'bestProgress': progress(rows),
            'activePlayers': len({row['userId'] for row in rows}),
        },
        'daily': daily,
        'members': members,
        'runs': recent,
    }


def request_user(request):
    authorization = request.headers.get('authorization', '')
    if authorization.startswith('Bearer access-'):
        user_id = authorization.removeprefix('Bearer access-')
        if user_id in users.values():
            return user_id
    return None


def parse_date(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')) if value else None


def handle(route):
    global team, stats_error_once
    request = route.request
    path = urlsplit(request.url).path
    method = request.method
    cors = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    }
    if method == 'OPTIONS':
        route.fulfill(status=204, body='', headers=cors)
        return
    body = json.loads(request.post_data) if request.post_data else {}
    user_id = request_user(request)
    call = {'path': path, 'body': body, 'user_id': user_id, 'url': request.url}
    calls.append(call)
    payload = None
    status = 200

    if path == '/auth/v1/token' and method == 'POST':
        user_id = users[body['email']]
        payload = {
            'access_token': 'access-' + user_id,
            'refresh_token': 'refresh-' + user_id,
            'expires_in': 3600,
            'user': {'id': user_id, 'email': body['email']},
        }
    elif path == '/auth/v1/logout':
        payload = {}
    elif path.startswith('/rest/v1/rpc/') and not user_id:
        payload, status = {'message': 'AUTH_REQUIRED'}, 401
    elif path == '/rest/v1/rpc/minuit_team_state':
        payload = member_state(user_id)
    elif path == '/rest/v1/rpc/minuit_create_team':
        if team or member_state(user_id)['team']:
            payload, status = {'message': 'ALREADY_IN_TEAM'}, 400
        else:
            team = {
                'id': '7d7e7382-1648-4e34-a6a2-f6d616bd4f75',
                'name': body['p_name'].strip(),
                'code': CODE,
                'adminId': user_id,
                'rulesConfigured': True,
                'dailyGameLimit': body['p_daily_game_limit'],
                'startsAt': body['p_starts_at'],
                'endsAt': body['p_ends_at'],
                'members': {
                    user_id: {'displayName': body['p_display_name'].strip(), 'attempts': [], 'runs': set()},
                },
            }
            payload = member_state(user_id)
    elif path == '/rest/v1/rpc/minuit_update_team_rules':
        if not team or team['adminId'] != user_id:
            payload, status = {'message': 'TEAM_ADMIN_REQUIRED'}, 400
        else:
            team['dailyGameLimit'] = body['p_daily_game_limit']
            team['startsAt'] = body['p_starts_at']
            team['endsAt'] = body['p_ends_at']
            team['rulesConfigured'] = True
            payload = member_state(user_id)
    elif path == '/rest/v1/rpc/minuit_join_team':
        normalized = re.sub(r'[^A-Za-z0-9]', '', body['p_code']).upper()
        if not team or team['code'] != normalized:
            payload, status = {'message': 'TEAM_NOT_FOUND'}, 400
        elif user_id in team['members']:
            payload, status = {'message': 'ALREADY_IN_TEAM'}, 400
        else:
            team['members'][user_id] = {
                'displayName': body['p_display_name'].strip(), 'attempts': [], 'runs': set(),
            }
            payload = member_state(user_id)
    elif path == '/rest/v1/rpc/minuit_submit_team_score':
        if not team or user_id not in team['members']:
            payload, status = {'message': 'NOT_IN_TEAM'}, 400
        else:
            member = team['members'][user_id]
            run_id = body['p_run_id']
            if run_id in member['runs']:
                payload = {
                    'bestScore': member.get('score') or 0,
                    'improved': False,
                    'duplicate': True,
                    'gamesToday': len(member['attempts']),
                    'gamesRemaining': games_remaining(member),
                }
            elif not team['rulesConfigured']:
                payload, status = {'message': 'TEAM_RULES_REQUIRED'}, 400
            elif team['startsAt'] and datetime.now(timezone.utc) < parse_date(team['startsAt']):
                payload, status = {'message': 'TEAM_PERIOD_NOT_STARTED'}, 400
            elif team['endsAt'] and datetime.now(timezone.utc) >= parse_date(team['endsAt']):
                payload, status = {'message': 'TEAM_PERIOD_ENDED'}, 400
            elif team['dailyGameLimit'] is not None and len(member['attempts']) >= team['dailyGameLimit']:
                payload, status = {'message': 'TEAM_DAILY_LIMIT'}, 400
            else:
                previous = member.get('score')
                improved = previous is None or body['p_score'] > previous
                member['runs'].add(run_id)
                member['attempts'].append({
                    'playedOn': datetime.now(PARIS).date().isoformat(),
                    'playedAt': datetime.now(timezone.utc).isoformat(),
                    'score': body['p_score'],
                    'mode': body['p_mode'],
                    'difficulty': body['p_difficulty'],
                    'stage': body['p_stage'],
                    'wave': body['p_wave'],
                    'runId': run_id,
                })
                if improved:
                    member.update({
                        'score': body['p_score'],
                        'mode': body['p_mode'],
                        'difficulty': body['p_difficulty'],
                        'stage': body['p_stage'],
                        'wave': body['p_wave'],
                        'updatedAt': '2026-10-25T13:00:00Z',
                    })
                payload = {
                    'bestScore': member['score'],
                    'improved': improved,
                    'duplicate': False,
                    'gamesToday': len(member['attempts']),
                    'gamesRemaining': games_remaining(member),
                }
    elif path == '/rest/v1/rpc/minuit_team_stats':
        days = body.get('p_days')
        if not team or user_id not in team['members']:
            payload, status = {'message': 'NOT_IN_TEAM'}, 400
        elif team['adminId'] != user_id:
            payload, status = {'message': 'TEAM_ADMIN_REQUIRED'}, 400
        elif not isinstance(days, int) or isinstance(days, bool) or not 1 <= days <= 365:
            payload, status = {'message': 'STATS_PERIOD_INVALID'}, 400
        elif stats_error_once:
            stats_error_once = False
            payload, status = {'message': 'Statistiques temporairement indisponibles.'}, 503
        else:
            payload = team_stats_state(user_id, days)
    elif path == '/rest/v1/rpc/minuit_reset_team_campaign':
        if not team or team['adminId'] != user_id:
            payload, status = {'message': 'TEAM_ADMIN_REQUIRED'}, 400
        else:
            for member in team['members'].values():
                member['attempts'].clear()
                member['runs'].clear()
                for key in ['score', 'mode', 'difficulty', 'stage', 'wave', 'updatedAt']:
                    member.pop(key, None)
            payload = member_state(user_id)
    elif path == '/rest/v1/rpc/minuit_delete_team':
        if not team or team['adminId'] != user_id:
            payload, status = {'message': 'TEAM_ADMIN_REQUIRED'}, 400
        else:
            team = None
            payload = {'team': None, 'scores': [], 'deleted': True}
    elif path == '/rest/v1/rpc/minuit_leave_team':
        if team:
            was_admin = team['adminId'] == user_id
            team['members'].pop(user_id, None)
            if not team['members']:
                team = None
            elif was_admin:
                team['adminId'] = next(iter(team['members']))
        payload = {'team': None, 'scores': []}
    else:
        payload, status = {'message': 'route inattendue'}, 404

    call['status'] = status
    route.fulfill(
        status=status,
        content_type='application/json',
        body=json.dumps(payload) if payload is not None else '',
        headers=cors,
    )


def login(page, email):
    if not page.locator('#cloudEmail').count():
        page.click('#archives')
    page.wait_for_selector('.cloud-email-access')
    if not page.locator('.cloud-email-access').evaluate('(node) => node.open'):
        page.click('.cloud-email-access summary')
    page.wait_for_selector('#cloudEmail', state='visible')
    page.fill('#cloudEmail', email)
    page.fill('#cloudPassword', 'mot-de-passe-jamais-stocke')
    page.click('#cloudLogin')
    page.wait_for_selector('#cloudSync')


def finish_run(page, score, stage_number=1, wave_number=1):
    if page.locator('#playAdventure').count():
        page.click('#playRanked')
        page.wait_for_selector('#launchLocal')
        page.click('#launchLocal')
    page.wait_for_function("state==='play' && mode==='ranked'")
    page.evaluate(f'gameTime=35;score={score};stage={stage_number - 1};wave={wave_number};end(false)')
    page.wait_for_selector('#teamResultStatus', state='attached')
    assert page.evaluate("MinuitLastScore.name===prefs.name && MinuitLastScore.name!=='Sorcière'")


def score_total(page):
    text = page.locator('.team-summary b').last.inner_text()
    return int(re.sub(r'\D', '', text))


with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
    errors = []

    def make_page(email, mobile=False, url='http://localhost:3000'):
        context = browser.new_context(
            viewport={'width': 390, 'height': 844} if mobile else {'width': 1366, 'height': 1000},
            is_mobile=mobile,
            has_touch=mobile,
        )
        context.route('**/supabase-config.js*', lambda route: route.fulfill(
            content_type='application/javascript',
            body=f"window.MINUIT_SUPABASE_CONFIG={{url:'{BASE}',publishableKey:'sb_publishable_test'}};",
        ))
        context.route(BASE + '/**', handle)
        context.add_init_script("(()=>{const profile=JSON.parse(localStorage.getItem('minuit-journey-v1')||'{}');localStorage.setItem('minuit-journey-v1',JSON.stringify({...profile,version:1,trainingDone:true}))})()")
        page = context.new_page()
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('dialog', lambda dialog: dialog.accept())
        page.goto(url)
        page.wait_for_function("document.querySelector('#playAdventure') || document.querySelector('#teamInviteCard')")
        login(page, email)
        return context, page

    context_a, alice = make_page('alice@example.com')
    alice.wait_for_selector('#teamCreate')
    alice.fill('#teamDisplayName', 'Alice')
    alice.fill('#teamName', 'Les Balais de minuit')
    alice.select_option('#teamRulesDailyLimit', '2')
    period = alice.evaluate("""()=>{
        const format=value=>new Date(value.getTime()-value.getTimezoneOffset()*60000).toISOString().slice(0,16);
        const now=new Date();
        return {starts:format(new Date(now.getTime()-86400000)),ends:format(new Date(now.getTime()+86400000))};
    }""")
    alice.fill('#teamRulesStartsAt', period['starts'])
    alice.fill('#teamRulesEndsAt', period['ends'])
    alice.click('#teamCreate')
    alice.wait_for_selector('#teamCopyCode')
    assert alice.locator('#teamCopyCode').inner_text() == 'ABCDE-23456'
    assert alice.locator('.team-row').count() == 1
    assert 'Alice' in alice.locator('.team-leaderboard').inner_text()
    assert alice.evaluate("prefs.name === 'Alice' && scorePlayerName() === 'Alice'")
    assert alice.locator('#teamSaveRules').count() == 1
    assert alice.locator('#teamStatsOpen').is_visible()
    assert not alice.locator('.team-admin-panel').evaluate('node=>node.open')
    assert alice.locator('.team-campaign-reset').is_visible()
    assert alice.locator('#teamResetCampaign').is_visible()
    assert alice.locator('#creatorWorldCode').is_visible()
    assert alice.locator('#creatorWorldCodeSubmit').is_visible()
    assert alice.evaluate("document.querySelector('.team-campaign-reset').compareDocumentPosition(document.querySelector('.team-email-share')) & Node.DOCUMENT_POSITION_FOLLOWING")
    assert '0/2 parties' in alice.locator('.team-rules-summary').inner_text()
    assert 'alice@example.com' not in alice.locator('#teamCard').inner_text()
    assert 'Supabase' not in alice.locator('body').inner_text()
    assert not alice.locator('#teamWhatsApp').is_visible()
    whatsapp = alice.locator('#teamWhatsApp').get_attribute('href')
    message = parse_qs(urlsplit(whatsapp).query)['text'][0]
    invitation = re.search(r'https?://\S+', message).group(0)
    assert parse_qs(urlsplit(invitation).query)['team'] == [CODE]
    assert 'ABCDE-23456' in message
    messenger = alice.locator('#teamMessenger').get_attribute('href')
    messenger_link = parse_qs(urlsplit(messenger).query)['u'][0]
    assert parse_qs(urlsplit(messenger_link).query)['team'] == [CODE]
    assert all(secret not in whatsapp + messenger for secret in ['access_token', 'refresh_token', 'traffic_access_token'])

    # Sur téléphone, l’admin voit aussi la campagne sans ouvrir les règles.
    admin_session = alice.evaluate("localStorage.getItem('minuit-supabase-session-v1')")
    mobile_admin_context = browser.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
    mobile_admin_context.route('**/supabase-config.js*', lambda route: route.fulfill(
        content_type='application/javascript',
        body=f"window.MINUIT_SUPABASE_CONFIG={{url:'{BASE}',publishableKey:'sb_publishable_test'}};",
    ))
    mobile_admin_context.route(BASE + '/**', handle)
    mobile_admin = mobile_admin_context.new_page()
    mobile_admin.on('pageerror', lambda error: errors.append(str(error)))
    mobile_admin.add_init_script("(()=>{const profile=JSON.parse(localStorage.getItem('minuit-journey-v1')||'{}');localStorage.setItem('minuit-journey-v1',JSON.stringify({...profile,version:1,trainingDone:true}))})()");mobile_admin.goto('http://localhost:3000')
    mobile_admin.evaluate('(value)=>localStorage.setItem(\'minuit-supabase-session-v1\',value)', admin_session)
    mobile_admin.reload()
    mobile_admin.wait_for_selector('#playAdventure')
    mobile_admin.click('#archives')
    mobile_admin.wait_for_selector('#teamResetCampaign')
    assert mobile_admin.locator('.team-campaign-reset').is_visible()
    assert not mobile_admin.locator('.team-admin-panel').evaluate('node=>node.open')
    stats_error_once = True
    mobile_admin.click('#teamStatsOpen')
    mobile_admin.wait_for_selector('.team-stats-error')
    assert 'Statistiques temporairement indisponibles.' in mobile_admin.locator('.team-stats-error').inner_text()
    mobile_admin.click('#teamStatsRetry')
    mobile_admin.wait_for_selector('.account-team-stats [data-stat="games"]')
    assert mobile_admin.locator('[data-stat="games"]').inner_text() == '0'
    assert mobile_admin.locator('[data-stats-empty="daily"]').count() == 1
    stats_mobile = mobile_admin.evaluate("""() => ({
        overlay:document.querySelector('#overlay').getBoundingClientRect().height,
        holder:document.querySelector('.layout>div:first-child').getBoundingClientRect().height,
        overflow:document.documentElement.scrollWidth>390,
        backVisible:document.querySelector('#teamStatsBack').getBoundingClientRect().top>=0
    })""")
    assert stats_mobile['overlay'] + 2 >= stats_mobile['holder'], stats_mobile
    assert not stats_mobile['overflow'] and stats_mobile['backVisible'], stats_mobile
    mobile_admin.screenshot(path='/tmp/team-stats-mobile-empty.png')
    mobile_admin.click('#teamStatsBack')
    mobile_admin.wait_for_selector('#teamResetCampaign')
    mobile_admin.locator('#teamResetCampaign').scroll_into_view_if_needed()
    reset_box = mobile_admin.locator('#teamResetCampaign').bounding_box()
    assert reset_box['x'] >= 0 and reset_box['x'] + reset_box['width'] <= 390
    assert reset_box['y'] >= 0 and reset_box['y'] + reset_box['height'] <= 844
    assert mobile_admin.evaluate('document.documentElement.scrollWidth<=390')
    mobile_admin.screenshot(path='/tmp/team-reset-mobile.png')
    mobile_admin_context.close()

    # L’invitation e-mail prépare le destinataire, l’objet, le code et le même lien sans jeton.
    assert alice.locator('#teamEmailInvite').is_visible()
    alice.evaluate("document.getElementById('teamEmailInvite').addEventListener('click',event=>event.preventDefault())")
    alice.fill('#teamInviteEmail', 'adresse-invalide')
    alice.click('#teamEmailInvite')
    assert 'adresse e-mail valide' in alice.locator('#teamStatus').inner_text()
    alice.fill('#teamInviteEmail', 'friend@example.com')
    email_invite = alice.locator('#teamEmailInvite').get_attribute('href')
    parsed_email = urlsplit(email_invite)
    email_query = parse_qs(parsed_email.query)
    assert parsed_email.scheme == 'mailto' and unquote(parsed_email.path) == 'friend@example.com'
    assert 'Les Balais de minuit' in email_query['subject'][0]
    assert 'ABCDE-23456' in email_query['body'][0]
    assert invitation in email_query['body'][0]
    assert all(secret not in email_invite for secret in ['access_token', 'refresh_token', 'traffic_access_token'])
    alice.click('#teamEmailInvite')
    assert 'Invitation préparée pour friend@example.com' in alice.locator('#teamStatus').inner_text()

    # Bob ouvre une invitation sur mobile : le code est prérempli et les jetons sont retirés de l’URL.
    context_b, bob = make_page('bob@example.com', mobile=True, url='http://localhost:3000/?team=abcde-23456&access_token=secret&refresh_token=secret&traffic_access_token=secret#session_id=secret')
    bob.wait_for_selector('#teamJoin')
    assert bob.locator('#teamCode').input_value() == 'ABCDE-23456'
    assert bob.evaluate("location.search==='' && location.hash===''")
    assert 'secret' not in bob.evaluate('location.href')
    bob.fill('#teamDisplayName', 'Bob')
    bob.click('#teamJoin')
    bob.wait_for_selector('#teamCopyCode')
    assert bob.locator('.team-row').count() == 2
    assert bob.evaluate("prefs.name === 'Bob' && scorePlayerName() === 'Bob'")
    assert bob.locator('#teamSaveRules').count() == 0
    assert bob.locator('#teamStatsOpen').count() == 0
    assert bob.locator('#teamResetCampaign').count() == 0
    assert bob.locator('.team-campaign-reset').count() == 0
    assert bob.locator('#creatorWorldCode').count() == 0
    assert not bob.evaluate("Campaign.redeemCreatorCode('Monde2')")
    assert bob.locator('#teamDelete').count() == 0
    assert bob.locator('#teamWhatsApp').is_visible() and bob.locator('#teamMessenger').is_visible()
    assert bob.locator('#teamEmailInvite').is_visible() and bob.locator('#teamInviteEmail').is_visible()
    assert bob.evaluate('document.documentElement.scrollWidth<=390')
    assert 'bob@example.com' not in bob.locator('#teamCard').inner_text()

    # Le classement dédié occupe aussi tout l’écran du téléphone.
    bob.click('#teamBoardOpen')
    bob.wait_for_selector('.account-team-board')
    board = bob.evaluate("""() => ({
        rows:document.querySelectorAll('.account-team-board .team-row').length,
        overlay:document.querySelector('#overlay').getBoundingClientRect().height,
        holder:document.querySelector('.layout>div:first-child').getBoundingClientRect().height,
        overflow:document.documentElement.scrollWidth>390
    })""")
    assert board['rows'] == 2 and board['overlay'] + 2 >= board['holder'], board
    assert not board['overflow'], board
    bob.click('#teamBoardBack')
    bob.wait_for_selector('#teamCopyCode')

    alice.click('#teamRefresh')
    alice.wait_for_function("document.querySelectorAll('.team-row').length===2")
    assert 'Bob' in alice.locator('.team-leaderboard').inner_text()

    # Deux parties par jour : le score faible compte quand même comme une tentative.
    alice.click('#archivesBack')
    finish_run(alice, 1500)
    alice.wait_for_function("document.querySelector('#teamResultStatus')?.textContent.includes('1 partie restante')")

    bob.click('#archivesBack')
    finish_run(bob, 2200, stage_number=3, wave_number=4)
    bob.wait_for_function("document.querySelector('#teamResultStatus')?.textContent.includes('Nouveau highscore')")

    alice.click('#retry')
    alice.wait_for_selector('#launchLocal')
    alice.click('#launchLocal')
    alice.wait_for_function("state==='play' && mode==='ranked'")
    alice.evaluate('gameTime=40;score=900;end(false)')
    alice.wait_for_function("document.querySelector('#teamResultStatus')?.textContent.includes('0 partie restante')")
    assert team['members'][ALICE]['score'] == 1500

    # La troisième partie est refusée, sans effacer le record ni interdire le jeu local.
    alice.click('#retry')
    alice.wait_for_selector('#launchLocal')
    alice.click('#launchLocal')
    alice.wait_for_function("state==='play' && mode==='ranked'")
    alice.evaluate('gameTime=45;score=1800;end(false)')
    alice.wait_for_function("document.querySelector('#teamResultStatus')?.textContent.includes('limite de parties comptabilisées')")
    assert len(team['members'][ALICE]['attempts']) == 2
    assert team['members'][ALICE]['score'] == 1500
    # Le refus team ne rend pas l’essai local : on réouvre un créneau de test
    # pour vérifier séparément l’acceptation après changement de règle admin.
    alice.evaluate("LocalLeague.dayState().rankedUsed=2;LocalLeague.save()")

    alice.click('#return')
    alice.click('#archives')
    alice.wait_for_function("document.querySelectorAll('.team-row').length===2 && document.querySelector('.team-row').textContent.includes('Bob')")
    assert score_total(alice) == 3700
    assert '2/2 parties' in alice.locator('.team-rules-summary').inner_text()

    # Seul l’admin peut relever la limite ; la nouvelle tentative est alors acceptée.
    alice.click('.team-admin-panel summary')
    alice.select_option('#teamEditDailyLimit', '3')
    alice.click('#teamSaveRules')
    alice.wait_for_function("document.querySelector('#teamStatus').textContent.includes('Règles de la team enregistrées')")
    assert team['dailyGameLimit'] == 3
    assert '2/3 parties' in alice.locator('.team-rules-summary').inner_text()

    alice.click('#archivesBack')
    finish_run(alice, 1800)
    alice.wait_for_function("document.querySelector('#teamResultStatus')?.textContent.includes('Nouveau highscore')")
    assert len(team['members'][ALICE]['attempts']) == 3
    assert team['members'][ALICE]['score'] == 1800

    alice.click('#return')
    alice.click('#archives')
    alice.wait_for_function("document.querySelectorAll('.team-row').length===2 && document.querySelector('.team-row').textContent.includes('Bob')")
    alice.wait_for_function("document.querySelector('.team-rules-summary').textContent.includes('3/3 parties')")
    assert 'Bob' in alice.locator('.team-row').first.inner_text()
    assert 'Alice' in alice.locator('.team-row').nth(1).inner_text()
    assert score_total(alice) == 4000
    highscore_cells = alice.locator('#teamCard .team-score')
    assert highscore_cells.count() == 2
    assert [int(re.sub(r'\D', '', value)) for value in highscore_cells.all_inner_texts()] == [2200, 1800]
    assert all(highscore_cells.nth(index).is_visible() for index in range(2))

    # Les statistiques additionnent tous les vols acceptés, pas seulement les highscores.
    stats_unauthorized = bob.evaluate("""async () => {
        const session=JSON.parse(localStorage.getItem('minuit-supabase-session-v1'));
        const response=await fetch('https://night-test.supabase.co/rest/v1/rpc/minuit_team_stats',{
            method:'POST',headers:{apikey:'sb_publishable_test',Authorization:'Bearer '+session.access_token,'Content-Type':'application/json'},body:JSON.stringify({p_days:30})
        });
        return response.status;
    }""")
    assert stats_unauthorized == 400
    alice.click('#teamStatsOpen')
    alice.wait_for_selector('.account-team-stats [data-stat="games"]')
    assert int(re.sub(r'\D', '', alice.locator('[data-stat="games"]').inner_text())) == 4
    assert int(re.sub(r'\D', '', alice.locator('[data-stat="points"]').inner_text())) == 6400
    assert int(re.sub(r'\D', '', alice.locator('[data-stat="bestScore"]').inner_text())) == 2200
    assert int(re.sub(r'\D', '', alice.locator('[data-stat="activePlayers"]').inner_text())) == 2
    assert 'M3 · V4' in alice.locator('[data-stat="bestProgress"]').inner_text()
    assert 'Le château des vampires' in alice.locator('[data-stat="bestProgress"]').inner_text()
    assert alice.locator('.team-stats-day').count() == 1
    daily_cells = alice.locator('.team-stats-day td')
    assert int(re.sub(r'\D', '', daily_cells.nth(1).inner_text())) == 4
    assert int(re.sub(r'\D', '', daily_cells.nth(3).inner_text())) == 6400
    assert int(re.sub(r'\D', '', daily_cells.nth(4).inner_text())) == 2200
    assert 'M3 · V4' in daily_cells.nth(2).inner_text()
    assert alice.locator('.team-stats-member').count() == 2
    assert 'Alice' in alice.locator('.team-stats-member').nth(0).inner_text()
    assert int(re.sub(r'\D', '', alice.locator('.team-stats-member').nth(0).locator('td').nth(1).inner_text())) == 3
    assert int(re.sub(r'\D', '', alice.locator('.team-stats-member').nth(0).locator('td').nth(3).inner_text())) == 4200
    assert 'Bob' in alice.locator('.team-stats-member').nth(1).inner_text()
    assert int(re.sub(r'\D', '', alice.locator('.team-stats-member').nth(1).locator('td').nth(3).inner_text())) == 2200
    assert alice.locator('.team-stats-run').count() == 4
    stats_text = alice.locator('.account-team-stats').inner_text()
    assert all(secret not in stats_text for secret in ['alice@example.com', 'bob@example.com', ALICE, BOB])
    assert 'somme des scores de tous les vols comptabilisés' in stats_text
    alice.screenshot(path='/tmp/team-stats-desktop.png')
    alice.select_option('#teamStatsDays', '7')
    alice.wait_for_selector('.account-team-stats [data-stat="games"]')
    assert int(re.sub(r'\D', '', alice.locator('[data-stat="games"]').inner_text())) == 4
    stats_calls = [call for call in calls if call['path'].endswith('/minuit_team_stats')]
    assert stats_calls[-1]['body'] == {'p_days': 7}
    assert any(call['user_id'] == BOB and call['status'] == 400 for call in stats_calls)
    alice.click('#teamStatsBack')
    alice.wait_for_selector('#teamStatsOpen')

    # Seul l’admin peut remettre toute la campagne à zéro, highscores compris.
    unauthorized = bob.evaluate("""async () => {
        const session=JSON.parse(localStorage.getItem('minuit-supabase-session-v1'));
        const response=await fetch('https://night-test.supabase.co/rest/v1/rpc/minuit_reset_team_campaign',{
            method:'POST',headers:{apikey:'sb_publishable_test',Authorization:'Bearer '+session.access_token,'Content-Type':'application/json'},body:'{}'
        });
        return response.status;
    }""")
    assert unauthorized == 400 and score_total(alice) == 4000
    assert not alice.locator('.team-admin-panel').evaluate('node=>node.open')
    assert alice.locator('.team-campaign-reset').is_visible()
    alice.click('#teamResetCampaign')
    alice.wait_for_function("document.querySelector('#teamStatus').textContent.includes('Campagne réinitialisée')")
    assert 'tous les scores et toutes les parties sont à zéro' in alice.locator('#teamResetStatus').inner_text()
    assert score_total(alice) == 0
    assert '0/3 parties' in alice.locator('.team-rules-summary').inner_text()
    assert alice.locator('.team-score').all_inner_texts() == ['0', '0']
    assert team['dailyGameLimit'] == 3 and len(team['members']) == 2
    for member in team['members'].values():
        assert member['attempts'] == [] and not member['runs'] and 'score' not in member
    alice.click('#teamStatsOpen')
    alice.wait_for_selector('.account-team-stats [data-stat="games"]')
    assert alice.locator('[data-stat="games"]').inner_text() == '0'
    assert alice.locator('[data-stat="points"]').inner_text() == '0'
    assert alice.locator('.team-stats-member').count() == 2
    assert alice.locator('.team-stats-day').count() == 0 and alice.locator('.team-stats-run').count() == 0
    assert alice.locator('[data-stats-empty="daily"]').count() == 1
    assert alice.locator('[data-stats-empty="runs"]').count() == 1
    alice.click('#teamStatsBack')
    alice.wait_for_selector('#teamResetCampaign')
    reset_calls = [call for call in calls if call['path'].endswith('/minuit_reset_team_campaign')]
    assert [(call['user_id'], call['status']) for call in reset_calls] == [(BOB, 400), (ALICE, 200)]

    # Le raccourci réservé au créateur ouvre la vraie scène, sans fabriquer de résultat.
    local_before = alice.evaluate("JSON.stringify({records:JSON.parse(localStorage.getItem('minuit-v2-scores')||'[]'),recent:Journey.state.recent})")
    alice.fill('#creatorWorldCode', 'incorrect')
    alice.click('#creatorWorldCodeSubmit')
    assert 'Code incorrect' in alice.locator('#creatorWorldCodeStatus').inner_text()
    assert alice.evaluate('state') == 'journey-archives'
    alice.fill('#creatorWorldCode', 'Monde2')
    alice.click('#creatorWorldCodeSubmit')
    alice.wait_for_selector('#skipFinale')
    assert alice.evaluate("state==='sequel-finale' && Campaign.progress.world2Unlocked && Campaign.progress.cardOath")
    assert alice.evaluate("JSON.stringify({records:JSON.parse(localStorage.getItem('minuit-v2-scores')||'[]'),recent:Journey.state.recent})") == local_before
    alice.click('#skipFinale')
    alice.wait_for_selector('#testWorld2')
    assert 'aucun score' in alice.locator('.sequel-unlocked').inner_text()
    assert alice.evaluate("JSON.stringify({records:JSON.parse(localStorage.getItem('minuit-v2-scores')||'[]'),recent:Journey.state.recent})") == local_before
    alice.click('#unlockMenu')
    alice.wait_for_selector('#playAdventure')
    alice.click('#archives')
    alice.wait_for_selector('#creatorWorldCode')

    # Le départ retire ensuite le membre, sans faire réapparaître les scores effacés.
    bob.click('#return')
    bob.click('#archives')
    bob.wait_for_selector('#teamLeave')
    bob.click('#teamRefresh')
    bob.wait_for_function("document.querySelector('#teamStatus').textContent.includes('Classement actualisé')")
    assert bob.locator('#teamResetCampaign').count() == 0
    assert score_total(bob) == 0
    assert '0/3 parties' in bob.locator('.team-rules-summary').inner_text()
    bob.click('#teamLeave')
    bob.wait_for_selector('#teamJoin')
    alice.click('#teamRefresh')
    alice.wait_for_function("document.querySelectorAll('.team-row').length===1")
    assert 'Bob' not in alice.locator('.team-leaderboard').inner_text()
    assert score_total(alice) == 0

    # Le départ du dernier membre efface la team et ses données.
    alice.click('#teamLeave')
    alice.wait_for_selector('#teamJoin')
    assert team is None
    assert 'team vide' in alice.locator('#teamStatus').inner_text()

    # Une nouvelle team à deux membres peut être supprimée explicitement par son admin.
    alice.fill('#teamDisplayName', 'Alice')
    alice.fill('#teamName', 'Team à supprimer')
    alice.click('#teamCreate')
    alice.wait_for_selector('#teamDelete')
    bob.fill('#teamDisplayName', 'Bob')
    bob.fill('#teamCode', CODE)
    bob.click('#teamJoin')
    bob.wait_for_selector('#teamCopyCode')
    assert bob.locator('#teamDelete').count() == 0
    alice.click('#teamRefresh')
    alice.wait_for_function("document.querySelectorAll('.team-row').length===2")
    alice.click('#teamDelete')
    alice.wait_for_selector('#teamJoin')
    assert team is None
    assert 'Team supprimée' in alice.locator('#teamStatus').inner_text()
    bob.click('#teamRefresh')
    bob.wait_for_selector('#teamJoin')
    deletion = [call for call in calls if call['path'].endswith('/minuit_delete_team')]
    assert len(deletion) == 1 and deletion[0]['user_id'] == ALICE and deletion[0]['status'] == 200

    stored = alice.evaluate("Object.keys(localStorage).map(key=>localStorage.getItem(key)).join('\\n')")
    assert 'mot-de-passe-jamais-stocke' not in stored
    assert 'friend@example.com' not in stored
    submissions = [call for call in calls if call['path'].endswith('/minuit_submit_team_score')]
    assert [call['body']['p_score'] for call in submissions] == [1500, 2200, 900, 1800, 1800]
    assert submissions[3]['status'] == 400 and submissions[4]['status'] == 200
    assert all(call['body']['p_mode'] == 'ranked' and call['body']['p_run_id'] for call in submissions)
    assert len({(call['user_id'], call['body']['p_run_id']) for call in submissions}) == 5
    assert not errors, errors
    print('OK : statistiques admin, totaux par jour et par membre, refus non-admin, règles, réinitialisation complète, invitations, suppression et mobile.')
    context_a.close()
    context_b.close()
    browser.close()

schema = (ROOT / 'supabase/teams.sql').read_text()
rules = (ROOT / 'supabase/team_rules.sql').read_text()
stats = (ROOT / 'supabase/team_stats.sql').read_text()
legacy = (ROOT / 'supabase/team_legacy_highscores.sql').read_text()
legacy_executable = '\n'.join(line for line in legacy.splitlines() if not line.lstrip().startswith('--'))
assert "update public.team_scores" in legacy_executable
assert "set mode = 'ranked'" in legacy_executable and "where mode = 'free'" in legacy_executable
assert "updated_at < '2026-10-31 11:36:25+00'" in legacy_executable
assert 'team_score_attempts' not in legacy_executable
assert schema.count('security definer') == 5
assert rules.count('security definer') == 7
assert 'revoke all on table public.team_scores from anon, authenticated' in schema
assert 'revoke all on table public.team_score_attempts from anon, authenticated' in rules
assert "set search_path = ''" in rules
assert 'minuit_update_team_rules' in rules and 'TEAM_DAILY_LIMIT' in rules
assert "p_mode not in ('ranked', 'free')" in rules and "ts.mode = 'ranked'" in rules
assert "and ta.mode in ('ranked', 'free')" in stats and "and ts.mode = 'ranked'" in stats
assert 'TEAM_PERIOD_NOT_STARTED' in rules and 'TEAM_PERIOD_ENDED' in rules
assert 'grant execute on function public.minuit_update_team_rules(integer, timestamptz, timestamptz) to authenticated' in rules
assert 'grant execute on function public.minuit_reset_team_campaign() to authenticated' in rules
assert 'delete from public.team_score_attempts ta where ta.team_id = v_team_id' in rules
assert 'delete from public.team_scores ts where ts.team_id = v_team_id' in rules
assert 'perform tm.user_id from public.team_members tm' in rules
assert 'grant execute on function public.minuit_delete_team() to authenticated' in rules
assert 'delete from public.teams t' in rules and 't.created_by = v_uid' in rules
assert stats.count('security definer') == 1
assert 'public.minuit_team_stats(p_days integer default 30)' in stats
assert 't.id = v_team_id and t.created_by = v_uid' in stats
assert 'from public.team_score_attempts ta' in stats and 'sum(ta.score)' in stats
assert 'ta.played_on between v_since and v_until' in stats
assert 'limit 50' in stats and 'auth.users' not in stats and '"userId"' not in stats
assert 'revoke all on function public.minuit_team_stats(integer) from public, anon, authenticated' in stats
assert 'grant execute on function public.minuit_team_stats(integer) to authenticated' in stats
assert not any('to anon' in line for line in (schema + rules + stats).splitlines() if line.strip().startswith('grant execute'))
print('OK : tentatives privées, statistiques réservées au créateur, fonctions authentifiées uniquement et search_path figé.')
